# CSE6010 Assignment-2

## Operating System and Compiler
Apple clang version 13.1.6 (clang-1316.0.21.2.5)
Target: arm64-apple-darwin21.5.0
Thread model: posix

## Command Lines
compile command:
gcc main.c node.c -o program

run command:
./program