# CSE6010 Assignment-1

## Operating System and Compiler
Apple clang version 13.1.6 (clang-1316.0.21.2.5)
Target: arm64-apple-darwin21.5.0
Thread model: posix

## Command Line
make counting
cc     counting.c   -o counting
./counting